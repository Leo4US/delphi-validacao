# Bases do questionário

Arquivos CSV contendo os itens do questionário por bloco/seção.

Formato esperado (colunas mínimas):
- secao
- codigo
- texto
- tematica

Valores recomendados para tematica (padronizados):
- Sociodemografico
- Organizacao do trabalho
- Saude e seguranca
- Meio ambiente
- Politicas publicas genero e cultura
