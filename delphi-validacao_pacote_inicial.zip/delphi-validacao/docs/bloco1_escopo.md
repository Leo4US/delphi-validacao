# Escopo do Bloco 1 – Fase Piloto

O Bloco 1 é utilizado exclusivamente como protótipo para teste do layout, do fluxo de validação Delphi e do armazenamento das respostas.

As decisões registradas nesta fase não possuem caráter definitivo e não constituem ainda a rodada Delphi oficial do projeto.

O objetivo principal é validar o funcionamento da ferramenta antes da expansão para os demais blocos do questionário.
